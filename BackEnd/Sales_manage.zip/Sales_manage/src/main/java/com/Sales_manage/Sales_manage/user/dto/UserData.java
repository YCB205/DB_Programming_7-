package com.Sales_manage.Sales_manage.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserData {
    private String id;
    private String passwd;
    private String email;
    private String name;
    private String phoneNumber;

}

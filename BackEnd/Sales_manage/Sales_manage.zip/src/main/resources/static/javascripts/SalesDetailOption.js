
//MainPageCanvasAdapter를 클릭시 어떤걸 노출할것이고 노출 안할것인지를 결정

const whatOptionChoose = document.getElementById('selectDivOptionDetails');
//chartRadio버튼
const dropDownMenueForSale =()=>{
    whatOptionChoose.style.display = 'flex';

}
export {dropDownMenueForSale}



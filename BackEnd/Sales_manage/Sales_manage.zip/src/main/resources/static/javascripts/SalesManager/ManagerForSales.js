// 서버로 데이터 요청
window.onload = function () {
    getData();
    console.log('창이 열렸습니다.');
    const btn = document.getElementById('fetchData');
    btn.addEventListener('click', function () {
        //검색실행
        getTime();
    })
    const startDate = document.getElementById('fromDate');
    const endDate = document.getElementById('toDate');
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    const setDefault = convertTimeType(currentDate);
    startDate.value = setDefault;
    endDate.value = setDefault;


    startDate.addEventListener('change', function () {
        checkTimeValid();
    })
    endDate.addEventListener('change', function () {
        checkTimeValid();
    })
    let btncheck = document.getElementById('btncheck');
    btncheck.addEventListener("click", function () {
        changeChart(btncheck.value);
        hideTable(btncheck.value);
    })
}


function getData() {
    let officeName = [];
    let name = '';
    fetch(`/branch-storeManagers?officeName=${officeName}&name=${name}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            // You may include other headers if needed
        },
    })
        .then(response => response.json())
        .then(data => {
            // 성공적으로 처리된 경우의 동작
            console.log('Data successfully received:', data);
            addBtnRadio(data);
        })
        .catch(error => {
            // 오류 발생 시 처리
            console.error('Error getting products:', error);
        });
}


function addBtnRadio(data) {
    let btngroup = document.getElementById('btngroup');
    // <input type="checkbox" className="btn-check" name="btncheck" id="btncheck1" autoComplete="off">-->
    //     <!--                    <label class="btn btn-outline-primary rounded-0 m-0" for="btncheck1">공주대 천안점</label>-->
    for (let i = 0; i < data.length; i++) {
        let input = document.createElement('input');
        input.setAttribute('type', 'radio');
        input.setAttribute('class', 'btn-check');
        input.setAttribute('name', 'btncheck');
        input.setAttribute('id', `${data[i][0].idStoreManager}`);
        input.setAttribute('autoComplete', 'off');
        input.setAttribute('value', `${data[i][0].officeName}`);
        let label = document.createElement('label');
        label.classList.add('btn', 'btn-outline-primary', 'rounded-0', 'm-0');
        label.setAttribute('for', `${data[i][0].idStoreManager}`);
        label.textContent = `${data[i][0].officeName}`;
        btngroup.appendChild(input);
        btngroup.appendChild(label);
        input.addEventListener('change', function () {
            changeChart(this.value);
            hideTable(this.value);
        })
    }
}

function checkTimeValid() {
    const fromDate = document.getElementById('fromDate');
    const toDate = document.getElementById('toDate');
    let curruentTime = new Date();
    let startValue = new Date(fromDate.value);
    let endValue = new Date(toDate.value);
    if (startValue > endValue) {
        fromDate.value = toDate.value;
    } else if (endValue > curruentTime) {
        toDate.value = convertTimeType(curruentTime);
    }
}

function getTime() {
    const startTime = document.getElementById('fromDate');
    const endTime = document.getElementById('toDate');
    getFetch(startTime.value, endTime.value);
}


//fetch부르기
function getFetch(startdate, enddate) {
    const product = [];
    const company = [];
    const startDate = convertTimeType(startdate);
    const endDate = convertTimeType(enddate);
    const getRadio = document.getElementById('optionsRadios2');
    if (getRadio.checked) {
        const getLocal = localStorage.getItem('table_info');
        const data = JSON.parse(getLocal);
        data.productsList.forEach((value, index) => {
            product.push(value.merchandiseName.toString());
        })
    }
    const url = `/allOrderproducts?search_merchandise=${product}&startDateTime=` + startDate + "&endDateTime=" + endDate + `&brandoffice_id=${company}`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            addTableRow(data);
        })
}

function convertTimeType(inputDateTime) {
    const date = new Date(inputDateTime);

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    const formattedDate = `${year}-${month}-${day}`;
    const formattedTime = `${hours}:${minutes}:${seconds}`;
    console.log((`${formattedDate} ${formattedTime}`));
    return ((`${formattedDate} ${formattedTime}`));
}

let myMap = new Map();
let jumjuMap = new Map();
let labels = [];
let salesData = [];
let profitsData = [];
let salesData2 = [];
let profitsData2 = [];
function groupAndConvertToJSON(data) {
    const groupedData = {};

    // 데이터를 그룹화합니다.
    data.forEach(item => {
        const key = item[0]; // [0]번째 숫자 값을 그룹화 키로 사용합니다.

        if (!groupedData[key]) {
            groupedData[key] = [];
        }

        // 데이터를 JSON 객체로 변환하여 그룹에 추가합니다.
        groupedData[key].push({
            jumju: item[1],
            category: item[2],
            id: item[3],
            name: item[4],
            profit: item[6],
            sales: item[7],
        });
    });

    // 그룹화된 데이터를 배열로 변환합니다.
    const result = Object.values(groupedData);

    return result;
}

function addTableRow(data) {
    const tbody = document.getElementById('tbody');
    //데이터 전처리하기
    const groupedAndConvertedData = groupAndConvertToJSON(data);
    console.log(groupedAndConvertedData);
    myMap.clear();
    jumjuMap.clear();
    labels.length = 0;
    salesData.length = 0;
    salesData2.length = 0;
    profitsData.length = 0;
    profitsData2.length = 0;
    //자식요소 삭제하기
    while (tbody.firstChild) {
        console.log("삭제합니다..");
        tbody.removeChild(tbody.firstChild);
    }
    let getRadio = document.getElementById('optionsRadios1');
    for (let index = 0; index < groupedAndConvertedData.length - 1; index++) {
        const ordersheet = groupedAndConvertedData[index];
        let trClass = document.createElement('tr');
        index % 2 === 0 ? trClass.setAttribute('class', 'table-right') : trClass.setAttribute('class', 'table-success');
        let th = document.createElement('th');
        th.setAttribute('rowspan', ordersheet.length + 1);
        th.setAttribute('scope', 'row');
        th.setAttribute('style', 'vertical-align: middle');
        let jumju = ordersheet[0].jumju;
        th.textContent = jumju;
        th.setAttribute('id', ordersheet[0].jumju);
        trClass.appendChild(th);
        tbody.appendChild(trClass);
        myMap.set(jumju, 0);
        jumjuMap.set(jumju, 0);
        let list = [0, 0];
        let categoryMap = new Map();
        for (let jdex = 0; jdex < ordersheet.length; jdex++) {
            let data = ordersheet[jdex];
            let tr = document.createElement('tr');
            let td1 = document.createElement('td');
            let td2 = document.createElement('td');
            let td3 = document.createElement('td');
            let td4 = document.createElement('td');
            let td5 = document.createElement('td');

            jdex % 2 === 0 ? tr.setAttribute('class', 'table-right') : tr.setAttribute('class', 'table-success');
            td1.textContent = data.category;
            td2.textContent = data.id;
            td3.textContent = data.name;
            td4.textContent = `${data.profit}원`;
            td5.textContent = `${data.sales}원`;

            list[0] += data.profit;
            list[1] += data.sales;

            if(getRadio.checked) {
                //만약 카테고리가 없다면?
                if (categoryMap.get(data.category) == null) {
                        let list2 = [0, 0];
                        list2[0] += data.profit;
                        list2[1] += data.sales;
                    categoryMap.set(data.category, list2);
                } else {
                    let existingValue = categoryMap.get(data.category);
                    existingValue[0] += data.profit;
                    existingValue[1] += data.sales;
                }
            }
            else{

                    let list2 = [0, 0];
                    list2[0] += data.profit;
                    list2[1] += data.sales;
                    if(data.name!=='') {
                        categoryMap.set(data.name, list2);
                    }
                    else {
                        let profit = 0, sales = 0;
                        categoryMap.forEach((value,key)=>{
                            profit += value[0];
                            sales += value[1];
                        })
                        td4.textContent = `${data.profit}원`;
                        td5.textContent = `${data.sales}원`;
                        categoryMap.set(data.category, list2);
                    }
            }
            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            tr.appendChild(td4);
            tr.appendChild(td5);
            tbody.appendChild(tr);
            myMap.set(jumju, list);
        }
        jumjuMap.set(jumju, categoryMap);
    }
    drawBarChart();
    drawDoughnut();
    drawDoughnut2();
}

//차트를 그리기 위한 메서드

let myBarChart;
let myDoughnut;
let myDoughnut2;

function drawBarChart() {
    const canvas = document.getElementById('myAllChart');
    if (myBarChart !== undefined) {
        myBarChart.destroy();
    }
    canvas.style.width = '100%';
    let getRadio = document.getElementById('optionsRadios1');
    if(getRadio.checked) {
        let sumSale = 0;
        let sumProfit = 0;
        jumjuMap.forEach((value, key) => {
            labels.push(key);

            let sale = value.get("총매출");
            salesData.push(sale[0]);
            sumSale += sale[0];
            profitsData.push(sale[1]);
            sumProfit += sale[1];
        })
        console.log(sumSale);
        console.log(sumProfit);
        let sum2 = 0;
        jumjuMap.forEach((value,key)=>{
            let sale = value.get("총매출");
            sum2 += (sale[0]/sumSale)*100;
            salesData2.push((sale[0]/sumSale)*100);
            profitsData2.push((sale[1]/sumProfit)*100);
        })
        console.log(sum2);
    }
    else{
        let outsum = 0, outsum2 = 0;
        jumjuMap.forEach((value, key) => {
            labels.push(key);
            let sum1 = 0, sum2 = 0;
            value.forEach((value,key)=>{
                if(key!=="총매출") {
                    sum1 += value[0];
                    sum2 += value[1];
                    outsum += value[0];
                    outsum2 += value[1];
                    console.log(outsum);
                }
            })
            salesData.push(sum1);
            profitsData.push(sum2);
        })
        let sum = 0;
        for(let i= 0; i< salesData.length;i++){
            sum += salesData[i];
            console.log(sum);
            salesData2.push((salesData[i]/outsum)*100);
            profitsData2.push((profitsData[i]/outsum2)*100);
        }
        console.log(sum);
        console.log(outsum);
    }

    myBarChart = new Chart(canvas, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '영업이익',
                    data: salesData,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    fill: true
                },
                {
                    label: '매출액',
                    data: profitsData,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 2,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: ''
                }
            }
        }
    });

}

function drawDoughnut() {
    const canvas = document.getElementById('partChartTable');
    if (myDoughnut !== undefined) {
        myDoughnut.destroy();
    }
    console.log("labels_doughnut:"+salesData2);
    myDoughnut = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                label: '영업이익',
                data: salesData2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '영업이익(%)'
                }
            }
        }
    })
}

function drawDoughnut2() {
    const canvas = document.getElementById('partChartTable2');
    if (myDoughnut2 !== undefined) {
        myDoughnut2.destroy();
    }
    myDoughnut2 = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                label: '매출액',
                data: profitsData2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '매출액(%)'
                }
            }
        }
    })
}

function changeChart(value) {
    if(value.toString()==="all"){
        console.log(salesData);
        console.log(profitsData);
        myBarChart.data.datasets[0].data = salesData;
        myBarChart.data.datasets[1].data = profitsData;
        myBarChart.data.labels = labels;


        myDoughnut.data.datasets[0].data = salesData2;
        myDoughnut2.data.datasets[0].data = profitsData2;

        myDoughnut.data.labels = labels;
        myDoughnut2.data.labels = labels;

        myBarChart.update();
        myDoughnut.update();
        myDoughnut2.update();
        return;
    }
    let newlabe = [];
    let newlabe2 = [];
    let newlabeBar = [];
    let newsale = [];
    let newprofits = [];

    let newsale2 = [];
    let newprofits2 = [];


    let jumjunInfo = jumjuMap.get(value);
    //총매출 정보 얻어오기
    let wholeSale = jumjunInfo.get("총매출");
    let sumSale = 0;
    let sumProfit = 0;
    jumjunInfo.forEach((value, key) => {
        newlabe.push(key);
        newsale.push(value[0]);
        newprofits.push(value[1]);
        if(value[0] !== wholeSale[0]) {
            newsale2.push(value[0] / wholeSale[0] * 100);
            newprofits2.push(value[1] / wholeSale[1] * 100);
            sumSale += value[0];
            sumProfit += value[1];
        }
        else{
            if(sumSale !== wholeSale[0]){
                let sum1;
                let sum2;
                sum1 = (wholeSale[0] - sumSale)/wholeSale[0] * 100;
                sum2 = (wholeSale[1] - sumProfit)/wholeSale[1] * 100;
                newsale2.push(sum1);
                newprofits2.push(sum2);
            }
        }
    })
    myBarChart.data.datasets[0].data = newsale;
    myBarChart.data.datasets[1].data = newprofits;

    myBarChart.data.labels = newlabe;
    myBarChart.update();

    myDoughnut.data.datasets[0].data = newsale2;
    myDoughnut2.data.datasets[0].data = newprofits2;

    newlabe2=newlabe;
    const totalSalesIndex = newlabe2.indexOf("총매출");

    if (totalSalesIndex !== -1) {
        // "총매출"을 "항목을 제외한 나머지 비율"로 대체
        newlabe2[totalSalesIndex] = "항목을 제외한 나머지 비율";
        console.log("변경된 레이블" + newlabe2);

        // 변경된 레이블이 모든 제외할 항목을 포함하는지 확인
        const excludedItems  = ["블렌디드", "스타벅스 피지오", "프라푸치노"];
        if (excludedItems .every(item => newlabe2.includes(item))) {
            // 배열에서 해당 항목 제거
            newlabe2.splice(totalSalesIndex, 1);
            console.log("제외된 항목이 제거되었습니다"+newlabe2);
        }
    }

    myDoughnut.data.labels = newlabe2;
    myDoughnut2.data.labels = newlabe2;


    myDoughnut.update();
    myDoughnut2.update();
}

//테이블 정보 가져오기
window.addEventListener('message', function (event) {
    if (event.data === 'HTMLClosed') {
        const data = localStorage.getItem('table_info');
        const trList = JSON.parse(data);
        const chart = document.getElementById('productTable');
        let rowCount = chart.rows.length;

        for (let i = rowCount - 1; i >= 0; i--) {
            chart.deleteRow(i);
        }

        trList.productsList.forEach((value, index) => {
            const tr = document.createElement('tr');
            const td1 = document.createElement('td');
            const td2 = document.createElement('td');
            td1.setAttribute('scope', 'row');
            td1.textContent = value.id_merchandise.toString();
            td2.textContent = value.merchandiseName.toString();
            td1.setAttribute('class', 'col-2');
            td2.setAttribute('class', 'col-4');
            tr.appendChild(td1);
            tr.appendChild(td2);
            chart.append(tr);
        })
    }
})

//창이 닫히기전에 가지고 있던 값 삭제
window.addEventListener('beforeunload', function (event) {
    localStorage.removeItem('table_info');
});

function hideTable(value) {
    let tbody = document.getElementById('tbody');
    let trList = tbody.querySelectorAll('tr');
    if(value.toString()==='all'){
        for (let i = 0; i < trList.length; i++) {
                    trList[i].style.display ='';
            }
        return;
    }
    console.log(trList.length);
    for (let i = 0; i < trList.length; i++) {
        let th = trList[i].querySelector('th');
            if (th !==null && th.id.toString() === value) {
                console.log(th.rowSpan);
                let start = i;
                i += th.rowSpan - 1;
                let end = i;
                for(start; start <= end; start++){
                    trList[start].style.display ='';
                    console.log(trList[start]);
                }
            }
            else {
                trList[i].style.display = 'none';
            }
        }
}

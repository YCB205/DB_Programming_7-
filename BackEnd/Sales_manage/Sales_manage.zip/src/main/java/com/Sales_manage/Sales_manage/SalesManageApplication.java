package com.Sales_manage.Sales_manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesManageApplication.class, args);
	}

}

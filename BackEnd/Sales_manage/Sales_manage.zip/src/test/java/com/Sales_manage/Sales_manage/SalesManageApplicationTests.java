package com.Sales_manage.Sales_manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
